import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { db, collection, query, where, onSnapshot } from "../firebase";
import { BookingRequest } from "../types";
import { X, Calendar, Clock, MapPin, Phone, CheckCircle2, ShieldAlert, Sparkles, FolderOpen } from "lucide-react";

interface UserBookingsModalProps {
  onClose: () => void;
  onOpenBooking: () => void;
}

export const UserBookingsModal: React.FC<UserBookingsModalProps> = ({ onClose, onOpenBooking }) => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<BookingRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    // Subscribe to real-time user bookings from Firestore
    const bookingsRef = collection(db, "bookings");
    const q = query(bookingsRef, where("userId", "==", user.uid));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const list: BookingRequest[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          list.push({
            id: data.bookingId || docSnap.id,
            customerName: data.customerName || user.displayName || "User",
            phone: data.phone || "",
            address: data.address || "",
            city: data.city || "",
            area: data.area || "",
            serviceCategory: data.serviceCategory || "",
            providerId: data.providerId,
            providerName: data.providerName,
            preferredDate: data.preferredDate || "",
            preferredTime: data.preferredTime || "",
            notes: data.notes || "",
            status: data.status || "Pending",
            createdAt: data.createdAt ? new Date(data.createdAt).toLocaleDateString() : "Recently",
          });
        });
        setBookings(list);
        setLoading(false);
      },
      (err) => {
        console.error("Error loading user bookings from Firestore:", err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [user]);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-zinc-900 border-2 border-[#FFD400]/40 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200 text-white my-8 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FFD400] text-black flex items-center justify-center font-black">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-black text-white">My Service Bookings</h3>
              <p className="text-xs text-zinc-400">
                Logged in as <span className="text-[#FFD400] font-bold">{user?.displayName || user?.email}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto py-6 space-y-4">
          {loading ? (
            <div className="text-center py-12 space-y-3">
              <div className="w-8 h-8 border-2 border-[#FFD400] border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="text-xs text-zinc-400 font-bold">Syncing bookings from Firebase...</p>
            </div>
          ) : bookings.length === 0 ? (
            <div className="text-center py-12 px-4 space-y-4 bg-zinc-950/60 rounded-2xl border border-zinc-800">
              <FolderOpen className="w-12 h-12 text-zinc-600 mx-auto" />
              <div>
                <h4 className="text-base font-black text-white">No active bookings found</h4>
                <p className="text-xs text-zinc-400 max-w-xs mx-auto mt-1">
                  You haven't requested any local service bookings yet. Book a verified technician now!
                </p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onOpenBooking();
                }}
                className="btn-yellow px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider inline-flex items-center gap-2"
              >
                Book a Service Now
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {bookings.map((b) => (
                <div
                  key={b.id}
                  className="bg-black/80 border border-zinc-800 rounded-2xl p-5 hover:border-[#FFD400]/40 transition space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full bg-[#FFD400]/10 text-[#FFD400] border border-[#FFD400]/30 text-[10px] font-black uppercase tracking-wider">
                        #{b.id}
                      </span>
                      <h4 className="text-base font-black text-white mt-1 capitalize">
                        {b.serviceCategory} Service
                      </h4>
                      {b.providerName && (
                        <p className="text-xs font-bold text-zinc-400 mt-0.5">
                          Assigned Professional: <span className="text-white">{b.providerName}</span>
                        </p>
                      )}
                    </div>

                    <span
                      className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                        b.status === "Confirmed"
                          ? "bg-emerald-950 text-emerald-400 border-emerald-800"
                          : b.status === "Completed"
                          ? "bg-blue-950 text-blue-400 border-blue-800"
                          : "bg-amber-950 text-amber-400 border-amber-800"
                      }`}
                    >
                      {b.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-zinc-300 bg-zinc-950 p-3 rounded-xl border border-zinc-900">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-[#FFD400]" />
                      <span>{b.preferredDate} ({b.preferredTime})</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[#FFD400]" />
                      <span>{b.area ? `${b.area}, ` : ""}{b.city}</span>
                    </div>

                    <div className="flex items-center gap-2 sm:col-span-2">
                      <Phone className="w-3.5 h-3.5 text-[#FFD400]" />
                      <span>Contact Phone: {b.phone}</span>
                    </div>

                    {b.notes && (
                      <div className="sm:col-span-2 text-zinc-400 text-[11px] mt-1 pt-1 border-t border-zinc-800">
                        <strong>Note:</strong> {b.notes}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-zinc-800 text-right">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold transition"
          >
            Close Window
          </button>
        </div>
      </div>
    </div>
  );
};
